#==============================================================================#
# TITLE: What_ToDo_OOP
# Script to manage a collection of household tasks and their priorities, using
# a Class called Manage with several methods.
# A list of management options is as follows:
#
# Menu of Options
#    1) Show current data
#    2) Add a new item.
#    3) Remove an existing item.
#    4) Save Data to File
#    5) Exit Program
#
# AUTHOR: RER
# DATE: 4 May 2019
# ChangeLog (When, Who, What):
# ---- 4 May 2019, RER, Created Script
#==============================================================================#
#
class Manage(object):
#
    def load_data(line):
        global list, nline
        while line != '':
            line = infile.readline()
            if line == '':
                continue
            nline = nline + 1
            newline = line.replace('\n','')    
            newline = newline.split(',')
            dict = { newline[0] : newline[1] }
            list.append(dict)       
        print("Data from ToDo.txt is now loaded")
        return
#
    def print_data():
        global list, nline
        print("\nContents of the list (in dictionary form) are as follows:")
        for i in range(0,nline):
            print("task#",i,list[i])
        return
#
    def add_item():
        global list, nline
        new_task,new_priority = input("Enter new task, priority: ").split(',')
        new_dict = {new_task : new_priority}
        list.append(new_dict)
        print("\nRevised list of tasks is as follows:")
        nline = nline + 1
        for i in range(0,nline):
            print("task#",i,list[i])   
        return 
#
    def remove_item():
        global list, nline
        del_index = input("Enter the number of the task to be removed: ")
        del list[int(del_index)]
        print("\nRevised list of tasks is as follows:")
        nline = nline - 1
        for i in range(0,nline):
            print("task#",i,list[i])
        return
#
    def save_items():
        global list, nline
        outfile = open("RevisedToDo.txt",'w')
        outfile.write("This file contains a TODO list, each line in the form: TASK, PRIORITY\n")
        for i in range(0,nline):
            dict = list[i]
            for k,v in dict.items():
                key = k
                value = v
            outfile.write("%s,%s\n" %(key,value))
        print("\nRevised list is saved in a file named RevisedToDo.txt")
        outfile.close()
        return
#
# Start Application
#
# Open the file ToDo.txt
infile = open('ToDo.txt','r')
# Read and display file header
line = infile.readline()
print("\nHeader for file ToDo.txt:")
print(line)
#
list = []
nline = 0
#
# Load data from file
Manage.load_data(line)
#
# Display a menu of actions
print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
#
while (True):
# choose an option
    strChoice = str(input("\nWhich option would you like to perform? [1 to 5] - "))
# Show the current items in the table
    if (strChoice.strip() == '1'):
        Manage.print_data()
        continue
# Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        Manage.add_item()
        continue
# Remove an item from the list/Table
    elif(strChoice == '3'):
        Manage.remove_item()
        continue
# Save tasks to a file named RevisedToDo.txt
    elif(strChoice == '4'):
        Manage.save_items()
        continue
# Terminate file actions
    elif (strChoice == '5'):
        print("\nSession is ended")
        break #and end the script
#
infile.close()
input('\nPress ENTER to end script')





